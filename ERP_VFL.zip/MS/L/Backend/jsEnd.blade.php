<script src="{{asset('js/backend/app.js?nocahe=v1')}}"></script>


    <!-- Metis Menu Plugin JavaScript -->
   <!--   <script src="{{asset('vendor/metisMenu/metisMenu.min.js')}}"></script>-->

    <!-- Morris Charts JavaScript -->
  <!--    <script src="{{asset('vendor/raphael/raphael.min.js')}}"></script>
    <script src="{{asset('vendor/morrisjs/morris.min.js')}}"></script>
    <script src="{{asset('data/morris-data.js')}}"></script>-->

    <!-- Custom Theme JavaScript -->
 <!--     <script src="{{asset('dist/js/sb-admin-2.js')}}"></script>-->

 <!-- <script src="https://use.fontawesome.com/2452daee71.js"></script>-->