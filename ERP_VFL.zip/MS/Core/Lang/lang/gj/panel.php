<?php

// resources/lang/en/messages.php

return [
    'urhere' => 'તમે અહિંયા છો'
];


