@extends('B.L.Plate')
@section('Page-title')
<i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard
@endsection

@section('Page-content')
@include('Panel.V.home_data')
@endsection

@section('Page-breadcrumb')

@endsection