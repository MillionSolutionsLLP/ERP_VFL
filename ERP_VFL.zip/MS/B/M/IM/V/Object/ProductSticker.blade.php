<div  ms-link="{{ action('\B\IM\Controller@addWardPrintout',['UniqId'=>$data['TransactionCode']]) }}" class="ms-link" style="  height: 842px;
        width: 595px;
      
        margin-left: auto;
        margin-right: auto;">



<script type="text/javascript">
	
	var url=$('.ms-link').attr('ms-link');
	window.open(url,'_blank');
</script>