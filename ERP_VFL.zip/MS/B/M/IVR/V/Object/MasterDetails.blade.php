<div class="panel panel-default">
	
<div class="panel-heading"><h5><strong> <i class="glyphicon glyphicon-home"></i> Stock Module Home</strong></h5></div>
<div class="panel-body">


<div class="col-lg-6">



</div>

</div>


</div>