<?php
namespace B\SM;

class Logics{
	
}