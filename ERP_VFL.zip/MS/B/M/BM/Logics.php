<?php
namespace B\BM;

class Logics{
	
}