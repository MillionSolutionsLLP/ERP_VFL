
                    <div class="panel-footer">
                        <i class="{!!$data['icon']!!}" aria-hidden="true"></i> {!!$data['title']!!}

                    </div>

                    
            		  {!!$data['content']!!}
                    
       