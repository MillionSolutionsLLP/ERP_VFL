            <ul class="nav navbar-nav pull-right">
 


   <li class="visible-md visible-lg" role="presentation"><div class="loading ">
   	
   	<img src="<?php echo e(asset('/images/loading.gif')); ?>" width="40px" height="40px"> 
   </div> </li>



  <li class="bg-danger ms-border" role="presentation"><a href="<?php echo e(action('\B\Users\Controller@logout')); ?>"><i class="fa fa-sign-out" aria-hidden="true"></i> Sign out</a></li>
  
</ul>