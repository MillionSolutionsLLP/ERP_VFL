
<table class="table table-bordered table-hover">






    <tr>
    <th colspan="1"> <strong> HSN/SAC Details</strong> </th>
    <th colspan="1" > <strong class="btn btn-success ms-mod-btn pull-right" ms-live-link="<?php echo e(action('\B\MAS\Controller@editHSNSAC')); ?>"> <i class="glyphicon glyphicon-pencil"></i></strong> </th>
  
</tr>

	<tr>

	<th colspan="1"> <strong> Code Name</strong> </th>
	<th colspan="1"> <strong> HSN Code</strong> </th>

	
</tr>



<tbody>
<?php if(count($data['table']) > 0): ?>
    
    <?php $__currentLoopData = $data['table']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    	

    	
    	<td><?php echo e($row['HsnName']); ?></td>
    	<td><?php echo e($row['HsnCode']); ?></td>

    </tr>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php elseif(count($data['table']) == 0): ?>
 <tr ><center>
<td colspan="3"> 
 	<div class="col-lg-12 btn btn-info ms-mod-btn" ms-live-link="<?php echo e(action("\B\MAS\Controller@addTax")); ?>">Add New Tax</div></center>
</td>

 </tr>
<?php else: ?>
    Something is wrong !
<?php endif; ?>



</tbody>
	



</table>
