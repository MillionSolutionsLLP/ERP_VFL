<ul class="nav navbar-nav pull-left">


  <li class="ms-live-btn ms-border" ms-live-link="<?php echo e(action('\B\MAS\Controller@index')); ?>" role="presentation"><a class="" href="#" ><i class="fa fa-archive" aria-hidden="true"></i> Master</a></li>
	 <li class="ms-live-btn ms-border" role="presentation" ms-live-link="<?php echo e(action('\B\PM\Controller@index')); ?>"><a href="#" ><i class="fa fa-graduation-cap" aria-hidden="true"></i> Product </a></li>
	

	 <li class="ms-live-btn ms-border" role="presentation" ms-live-link="<?php echo e(action('\B\IM\Controller@index')); ?>"><a href="#" ><i class="fa fa-truck" aria-hidden="true"></i> Stock </a></li>


	 <li class="ms-live-btn ms-border" role="presentation" ms-live-link="<?php echo e(action('\B\BM\Controller@index')); ?>"><a href="#" ><i class="fa fa-download" aria-hidden="true"></i> Booking </a></li>
	



</ul>	