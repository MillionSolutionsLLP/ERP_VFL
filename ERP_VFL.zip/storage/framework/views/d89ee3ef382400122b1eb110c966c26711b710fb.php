
<div class="panel panel-default">
	
<div class="panel-heading"><h5><strong> <i class="glyphicon glyphicon-home"></i> Capital Contribution Charge Home</strong></h5></div>
<div class="panel-body">
	

<!-- 
<div class="col-lg-12">
	
<?php

$model=new \B\MM\Model();
		$tableData=$model->get()->toArray();
	
		$data=[

			'table'=>$tableData,
		];
//dd($data);
?>
<?php echo $__env->make("MM.V.Object.MemberList",['data'=>$data], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</div>

</div>
<div  class="panel-footer"></div>-->

</div>
