<br>
<div class="row">

    <div class="container-fluid">
<div class="col-lg-6" >
<?php echo $__env->make('B.L.Object.Home.Entry_Report', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<div class="col-lg-6 ">
<?php echo $__env->make('B.L.Object.Home.Recentaly_Applied', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>
</div>


