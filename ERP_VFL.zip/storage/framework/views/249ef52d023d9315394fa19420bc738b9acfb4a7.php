
<?php

	if(array_key_exists('ClassData', $data)){
	    	
		if(array_key_exists('form-class-div',$data['ClassData']))$input_class=$data['ClassData']['form-class-div'];

	
	}


//dd($data);
if(!array_key_exists('vName', $data))$data['vName']=$data['lable'];

//if(array_key_exists('editLock', $data))var_dump($data);

//if($data['vName'] =='Warehouse')dd($data);

?>

<div class="form-group  <?php echo e(isset($input_class) ? $input_class : 'col-lg-6'); ?>">

	<?php if(array_key_exists('link',$data)): ?>


	<?php



	$class="\\B\\".$data['link']['mod']."\\Model";

	$class=new $class ();


    if(substr($data['name'], -1) == ']'){

    	$data['funName']=substr($data['name'], 0, -2);

    }else{

    	$data['funName']=$data['name'];

    }

	//$data['vName']=$data['name'];
    if(array_key_exists('funName', $data))
    {
    	$function="get".$data['funName'];
     	$dlist=$class->$function ();


    
    }

	if(array_key_exists('index', $data))$index=$index+$data['index'];

	?>


<?php if(isset($dlist)): ?>

<datalist id="<?php echo e($data['name']); ?>List">
	<?php $__currentLoopData = $dlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value=>$key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <option value="<?php echo e($value); ?>"> <?php echo e($key); ?></option>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	
	</datalist>

<?php endif; ?>
	<?php endif; ?>





<?php echo e(Form::label($data['name'], $data['vName'])); ?>

    
<?php if(array_key_exists('editLock',$data)): ?>


	<?php if( $data['editLock']  ): ?>


 <fieldset disabled> 
 <?php echo e(Form::text($data['name'],$data['value'],['class'=>'form-control','tabindex'=>$index,'readonly','placeholder'=>'Enter '.$data['vName']] )); ?>

 </fieldset>



	<?php echo e(Form::hidden($data['name'], $data['value'])); ?>


<?php endif; ?>	


<?php else: ?>






      <?php echo e(Form::text($data['name'], $data['value'],['class'=>'form-control','list'=>$data['name'].'List','tabindex'=>$index,'placeholder'=>'Enter '.$data['lable'], 
    
    ]
     )); ?>



<?php endif; ?>	

</div>
