<div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
<fieldset disabled>
<?php echo e(Form::label($data['lable'], $data['name'])); ?> 
 <?php echo e(Form::text($data['name'], $data['value'],['class'=>'form-control','tabindex'=>$index,'readonly','placeholder'=>'Enter '.$data['lable']] )); ?>

</fieldset>


<?php if($data['editLock']): ?>

<?php if(array_key_exists('value',$data)): ?>
<?php echo e(Form::hidden($data['name'], $data['value'])); ?>

<?php endif; ?>
<?php endif; ?>


</div>

