




<div class="col-lg-2" style="padding-left: 0px; padding-right: 2px;">
	
<?php echo $__env->make("IM.V.Object.side", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>


<div class="col-lg-10" style="padding-right: 0px;padding-left: 2px;">
<div class="ms-mod-tab">
<?php echo $__env->make("IM.V.Object.MasterDetails",['data'=>$data], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</div>

</div>


