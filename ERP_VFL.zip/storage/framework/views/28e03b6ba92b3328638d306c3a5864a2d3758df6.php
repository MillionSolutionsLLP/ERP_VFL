
	<?php

	//$input_class='';

	if(array_key_exists('ClassData', $data)){
	    	
		if(array_key_exists('form-class-div',$data['ClassData']))
		$input_class=$data['ClassData']['form-class-div'];

	}


if(array_key_exists('index', $data))$index=$index+$data['index'];





	?>

<div class="form-group <?php echo e(isset($input_class) ? $input_class : 'col-lg-6'); ?>">
 <fieldset disabled>
    <?php echo e(Form::label($data['name'], $data['lable'])); ?>

    
    <?php echo e(Form::text($data['name'], $data['value'],['class'=>'form-control','tabindex'=>$index,'readonly','placeholder'=>'Enter '.$data['lable']] )); ?>

</fieldset>

<?php if(array_key_exists('value',$data)): ?>
<?php echo e(Form::hidden($data['name'], $data['value'])); ?>

<?php endif; ?>    
</div>