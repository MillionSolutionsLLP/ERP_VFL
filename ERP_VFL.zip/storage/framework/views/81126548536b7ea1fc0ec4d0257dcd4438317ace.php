<!DOCTYPE html>
<html lang="en">
<head>
	

	<?php echo $__env->make('Backend.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<?php
//dd($data);



$count=0;

?>

<body>

<div  style="   height: 842px;
        width: 595px;
      
        margin-left: auto;
        margin-right: auto;">


<div class="col-lg-12" style="padding: 0px;">
	
	<?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-lg-4 col-xs-4 col-sm-4 col-md-4" style="border-style: solid;border-width: 1px;">
			 
			<center>

					<br><?php echo '<img src="data:image/png;base64,' .\DNS1D::getBarcodePNG($value['UniqId'], "C39",1,50,array(1,1,1)). '" alt="barcode"   />'; ?>
				
				<br>
				<p style="text-align: left;">
					<small>
				Barcode: <?php echo e($value['UniqId']); ?>

			<br>Name: <?php echo e($data['productDetails']['name']); ?><br> Type: <?php echo e($data['productDetails']['type']); ?>

				</small>
				</p>				
			</center>
				
			
	</div>



			<?php if($loop->iteration > 20 && $loop->iteration < 22): ?>
			<div class="col-lg-12 col-xs-12 col-sm-12 col-md-12" style="min-height: 80px;"></div>
			<?php endif; ?>


			<?php if($loop->iteration > 41 && $loop->iteration < 43): ?>
			<div class="col-lg-12 col-xs-12 col-sm-12 col-md-12" style="min-height: 80px;"></div>
			<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




</div>



<script type="text/javascript">
	
	var url=$('.ms-link').attr('ms-link');
	window.open(url,'_blank');
</script>



    <?php echo $__env->make('Backend.jsEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>


</body>

</html>