<script src="<?php echo e(asset('js/backend/app.js?nocahe=v1')); ?>"></script>


    <!-- Metis Menu Plugin JavaScript -->
   <!--   <script src="<?php echo e(asset('vendor/metisMenu/metisMenu.min.js')); ?>"></script>-->

    <!-- Morris Charts JavaScript -->
  <!--    <script src="<?php echo e(asset('vendor/raphael/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/morrisjs/morris.min.js')); ?>"></script>
    <script src="<?php echo e(asset('data/morris-data.js')); ?>"></script>-->

    <!-- Custom Theme JavaScript -->
 <!--     <script src="<?php echo e(asset('dist/js/sb-admin-2.js')); ?>"></script>-->

 <!-- <script src="https://use.fontawesome.com/2452daee71.js"></script>-->