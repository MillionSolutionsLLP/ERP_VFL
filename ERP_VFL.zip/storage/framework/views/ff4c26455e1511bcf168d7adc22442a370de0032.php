<div class="panel panel-default">
	
<div class="panel-heading"><h5><strong> <i class="glyphicon glyphicon-home"></i> Member Module Home</strong></h5></div>
<div class="panel-body">
	


<div class="col-lg-12">


<?php echo $__env->make("MM.V.Object.ApproveList", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	</div>

</div>
<div class="panel-footer"></div>

</div>

