<ul class="nav navbar-nav pull-left">


  <li class="ms-live-btn ms-border" ms-live-link="<?php echo e(action('\B\MAS\Controller@index')); ?>" role="presentation"><a class="" href="#" ><i class="fa fa-cogs" aria-hidden="true"></i> Master</a></li>
	 <li class="ms-live-btn ms-border" role="presentation" ms-live-link="<?php echo e(action('\B\PM\Controller@index')); ?>"><a href="#" ><i class="fa fa-product-hunt" aria-hidden="true"></i> Product </a></li>
	

	 <li class="ms-live-btn ms-border" role="presentation" ms-live-link="<?php echo e(action('\B\SM\Controller@index')); ?>"><a href="#" ><i class="fa fa-balance-scale" aria-hidden="true"></i> Sales </a></li>



</ul>	