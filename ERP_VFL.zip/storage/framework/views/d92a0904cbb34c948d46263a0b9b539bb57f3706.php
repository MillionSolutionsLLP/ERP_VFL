<div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
    <?php echo e(Form::label($data['name'], $data['lable'])); ?>

    <?php echo e(Form::email($data['name'], $data['value'],['class'=>'form-control','tabindex'=>$index,'placeholder'=>'Enter '.$data['lable']] )); ?>

</div>