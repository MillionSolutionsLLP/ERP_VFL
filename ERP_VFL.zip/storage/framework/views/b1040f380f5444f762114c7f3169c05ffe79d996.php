<div class="">

    <div class="container-fluid">
<div class="col-lg-3">
	
<?php echo $__env->make("CCM.V.Object.side", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>


<div class="col-lg-9">
<div class="ms-mod-tab">
<?php echo $__env->make("CCM.V.Object.MasterDetails", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</div>

</div>
</div>
</div>