<div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
    <?php echo e(Form::label("Search", "Search",['class'=>'col-lg-6'])); ?>

    <?php echo e(Form::text("Search",null,['class'=>'form-control  col-lg-6','tabindex'=>'1','placeholder'=>'Enter Search'] )); ?>

    <?php
    $data=[
    	'data'=>[
    		'NameofBussiness'=>"Name of Member",
    		'ConnectionNo'=>"Connection Number",
    		'PlotNo'=>"Plot Number",
    		
    		'UniqId'=>"Unique Id ",
    	],
    	'name'=>"By"
    ];
    ?>
   


</div>

<div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
	<?php echo e(Form::label("By", "By",['class'=>'col-lg-6'])); ?>

 <?php echo e(Form::select($data['name'], $data['data'],null,['class'=>'form-control '])); ?>

</div>


<div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12">
<?php echo e(Form::button("Search",['class'=>"btn btn-info"] )); ?>

</div>
</div>