
                    <div class="panel-footer">
                        <i class="<?php echo $data['icon']; ?>" aria-hidden="true"></i> <?php echo $data['title']; ?>


                    </div>

                    
            		  <?php echo $data['content']; ?>

                    
       