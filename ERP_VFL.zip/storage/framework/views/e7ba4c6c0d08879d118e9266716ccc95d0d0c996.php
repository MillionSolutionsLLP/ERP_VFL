<ul class="nav navbar-nav pull-left">

<!--   <li role="presentation" class="ms-live-btn ms-history-btn" ms-live-link="#"><a href="#" ><i class="fa fa-search" aria-hidden="true"></i> Find Candidate</a></li> -->
  
  <li class="ms-live-btn" ms-live-link="<?php echo e(action('\B\MAS\Controller@index')); ?>" role="presentation"><a href="#" ><i class="fa fa-archive" aria-hidden="true"></i> Master</a></li>

  <li class="ms-live-btn" role="presentation" ms-live-link="<?php echo e(action('\B\MM\Controller@index')); ?>"><a href="#" ><i class="fa fa-users" aria-hidden="true"></i> Members</a></li>

  <li class="ms-live-btn" role="presentation" ms-live-link="<?php echo e(action('\B\CCM\Controller@index')); ?>"><a href="#" ><i class="fa fa-code-fork" aria-hidden="true"></i> Capital Contribution Charges</a></li>
  <li role="presentation"><a href="#" ><i class="fa fa-flask" aria-hidden="true"></i> Treatment Charges</a></li>
	
<!-- 	
  <li role="presentation"><a href="#" ><i class="fa fa-database" aria-hidden="true"></i> Export</a></li> -->
</ul>	