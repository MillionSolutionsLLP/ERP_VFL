<?php
//dd($data);
 ?>
<div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
<?php echo e(Form::label($data['lable'], $data['name'])); ?> 

<div class="radio">
<?php //	dd($data); ?>




<?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value=>$lable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<label tabindex="<?php echo e($index); ?>" class="form-conrtol">

	<?php if($value == $data['value']): ?>
	<?php echo e(Form::radio($data['name'], $value,true)); ?>

    <?php echo e($lable); ?>

	
	<?php else: ?>
    <?php echo e(Form::radio($data['name'], $value)); ?>

    <?php echo e($lable); ?>

	<?php endif; ?>
	
  	
  </label>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>

